# Analog Email Alert

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Ziqi-Liu/pen/019ffcaf-a4bd-7436-9063-bea36afa1b94](https://codepen.io/editor/Ziqi-Liu/pen/019ffcaf-a4bd-7436-9063-bea36afa1b94).

