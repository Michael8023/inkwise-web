import * as THREE from "three";

const canvas = document.querySelector("#scene");

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x91e5f1, 20, 46);

const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
camera.position.set(7.6, 4.9, 11.5);
camera.lookAt(0.45, 0.45, 0);

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: true,
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;

const hemiLight = new THREE.HemisphereLight(0xffffff, 0x6a5acd, 2.5);
scene.add(hemiLight);

const keyLight = new THREE.DirectionalLight(0xfff7dc, 5.2);
keyLight.position.set(-5, 9, 7);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
keyLight.shadow.camera.left = -8;
keyLight.shadow.camera.right = 8;
keyLight.shadow.camera.top = 8;
keyLight.shadow.camera.bottom = -8;
scene.add(keyLight);

const rimLight = new THREE.PointLight(0xff6fa4, 24, 14);
rimLight.position.set(5, 3, -3);
scene.add(rimLight);

const materials = {
  blue: new THREE.MeshStandardMaterial({
    color: 0x4676f4,
    roughness: 0.34,
    metalness: 0.04,
  }),
  cyan: new THREE.MeshStandardMaterial({
    color: 0x63e0dd,
    roughness: 0.28,
    metalness: 0.03,
  }),
  dark: new THREE.MeshStandardMaterial({ color: 0x142b44, roughness: 0.55 }),
  pink: new THREE.MeshStandardMaterial({ color: 0xff4f7e, roughness: 0.3 }),
  yellow: new THREE.MeshStandardMaterial({ color: 0xffdf4f, roughness: 0.4 }),
  white: new THREE.MeshStandardMaterial({ color: 0xfffdf5, roughness: 0.48 }),
  coral: new THREE.MeshStandardMaterial({ color: 0xff725e, roughness: 0.38 }),
};

function addEdges(mesh, color = 0x17324d, opacity = 0.28, threshold = 25) {
  const edges = new THREE.LineSegments(
    new THREE.EdgesGeometry(mesh.geometry, threshold),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity }),
  );
  mesh.add(edges);
  return mesh;
}

function roundedRectShape(width, height, radius) {
  const x = -width / 2;
  const y = -height / 2;
  const shape = new THREE.Shape();
  shape.moveTo(x + radius, y);
  shape.lineTo(x + width - radius, y);
  shape.quadraticCurveTo(x + width, y, x + width, y + radius);
  shape.lineTo(x + width, y + height - radius);
  shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  shape.lineTo(x + radius, y + height);
  shape.quadraticCurveTo(x, y + height, x, y + height - radius);
  shape.lineTo(x, y + radius);
  shape.quadraticCurveTo(x, y, x + radius, y);
  return shape;
}

function roundedPlane(width, height, radius, material) {
  return new THREE.Mesh(
    new THREE.ShapeGeometry(roundedRectShape(width, height, radius)),
    material,
  );
}

const mailbox = new THREE.Group();
mailbox.position.set(1.25, 0.3, 0);
mailbox.rotation.y = -0.08;
scene.add(mailbox);

const bodyShape = new THREE.Shape();
bodyShape.moveTo(-2.35, -1.1);
bodyShape.lineTo(2.35, -1.1);
bodyShape.lineTo(2.35, 0.55);
bodyShape.bezierCurveTo(2.35, 1.7, 1.35, 2.38, 0, 2.38);
bodyShape.bezierCurveTo(-1.35, 2.38, -2.35, 1.7, -2.35, 0.55);
bodyShape.closePath();

const bodyGeometry = new THREE.ExtrudeGeometry(bodyShape, {
  depth: 3.2,
  bevelEnabled: true,
  bevelSegments: 4,
  bevelSize: 0.1,
  bevelThickness: 0.1,
  curveSegments: 24,
});
bodyGeometry.translate(0, 0, -1.6);
const body = addEdges(new THREE.Mesh(bodyGeometry, materials.cyan));
body.castShadow = true;
body.receiveShadow = true;
mailbox.add(body);

const band = addEdges(
  new THREE.Mesh(new THREE.BoxGeometry(4.78, 0.5, 3.35), materials.blue),
);
band.position.y = -0.88;
band.castShadow = true;
mailbox.add(band);

const slotFrame = roundedPlane(3.25, 0.64, 0.3, materials.white);
slotFrame.position.set(0, 0.32, 1.72);
mailbox.add(slotFrame);

const slot = roundedPlane(2.72, 0.28, 0.14, materials.dark);
slot.position.set(0, 0.34, 1.735);
mailbox.add(slot);

const slotLabel = roundedPlane(1.38, 0.35, 0.16, materials.yellow);
slotLabel.position.set(0, -0.25, 1.74);
mailbox.add(slotLabel);

const post = addEdges(
  new THREE.Mesh(
    new THREE.CylinderGeometry(0.38, 0.48, 3.2, 20),
    materials.yellow,
  ),
);
post.position.set(0.45, -2.76, -0.2);
post.castShadow = true;
mailbox.add(post);

const foot = addEdges(
  new THREE.Mesh(
    new THREE.CylinderGeometry(1.35, 1.6, 0.42, 28),
    materials.coral,
  ),
);
foot.position.set(0.45, -4.25, -0.2);
foot.castShadow = true;
mailbox.add(foot);

const flower = new THREE.Group();
flower.position.set(1.38, 1.15, 1.75);
for (let i = 0; i < 5; i += 1) {
  const petal = new THREE.Mesh(
    new THREE.CircleGeometry(0.25, 24),
    materials.pink,
  );
  const angle = (i / 5) * Math.PI * 2;
  petal.position.set(Math.cos(angle) * 0.28, Math.sin(angle) * 0.28, 0);
  flower.add(petal);
}
const flowerCenter = new THREE.Mesh(
  new THREE.CircleGeometry(0.2, 24),
  materials.yellow,
);
flowerCenter.position.z = 0.01;
flower.add(flowerCenter);
mailbox.add(flower);

const flagPivot = new THREE.Group();
flagPivot.position.set(2.53, 0.2, 0.45);
flagPivot.rotation.y = Math.PI / 2;
flagPivot.rotation.z = -Math.PI / 2;
mailbox.add(flagPivot);

const flagArm = addEdges(
  new THREE.Mesh(new THREE.BoxGeometry(0.24, 2.35, 0.3), materials.pink),
  0x761b3c,
  0.24,
);
flagArm.position.y = 1.12;
flagArm.castShadow = true;
flagPivot.add(flagArm);

const flagHead = addEdges(
  new THREE.Mesh(new THREE.BoxGeometry(1.04, 0.78, 0.32), materials.pink),
  0x761b3c,
  0.24,
);
flagHead.position.set(0.39, 2.15, 0);
flagHead.castShadow = true;
flagPivot.add(flagHead);

const flagBolt = new THREE.Mesh(
  new THREE.CylinderGeometry(0.22, 0.22, 0.17, 20),
  materials.yellow,
);
flagBolt.rotation.z = Math.PI / 2;
flagBolt.position.set(2.52, 0.2, 0.64);
mailbox.add(flagBolt);

const envelope = new THREE.Group();
const envelopePaper = addEdges(
  new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.25, 0.1), materials.white),
);
envelopePaper.castShadow = true;
envelope.add(envelopePaper);

const stamp = new THREE.Mesh(
  new THREE.CircleGeometry(0.18, 20),
  materials.pink,
);
stamp.position.set(0.68, 0.35, 0.061);
envelope.add(stamp);

const seamMaterial = new THREE.LineBasicMaterial({
  color: 0x4676f4,
  transparent: true,
  opacity: 0.65,
});
const seamGeometry = new THREE.BufferGeometry().setFromPoints([
  new THREE.Vector3(-0.96, 0.55, 0.061),
  new THREE.Vector3(0, -0.18, 0.061),
  new THREE.Vector3(0.96, 0.55, 0.061),
]);
envelope.add(new THREE.Line(seamGeometry, seamMaterial));
envelope.rotation.x = -Math.PI / 2;
envelope.position.set(-1.8, 1.2, 4.0);
scene.add(envelope);

const ground = new THREE.Mesh(
  new THREE.CircleGeometry(7, 64),
  new THREE.ShadowMaterial({ color: 0x2f5793, opacity: 0.22 }),
);
ground.rotation.x = -Math.PI / 2;
ground.position.set(1.1, -4.16, 0);
ground.receiveShadow = true;
scene.add(ground);

const pointer = new THREE.Vector2(0.15, 0.12);
const smoothPointer = pointer.clone();
const raycaster = new THREE.Raycaster();
const pointerPlane = new THREE.Plane();
const planeNormal = new THREE.Vector3();
const followTarget = new THREE.Vector3();
const slotWorld = new THREE.Vector3();
const deliveryStart = new THREE.Vector3();
const deliveryStartQuaternion = new THREE.Quaternion();
const flatEnvelopeQuaternion = new THREE.Quaternion().setFromEuler(
  new THREE.Euler(-Math.PI / 2, 0, 0),
);
const cameraStart = camera.position.clone();
const clock = new THREE.Clock();
const clickableMeshes = [body, band, slotFrame, slot, flagArm, flagHead];

let state = "following";
let deliveryTime = 0;
let flagProgress = 0;
let mailboxBounce = 0;

function updatePointer(event) {
  pointer.x = (event.clientX / window.innerWidth) * 2 - 1;
  pointer.y = -(event.clientY / window.innerHeight) * 2 + 1;
}

function pointerHitsMailbox() {
  raycaster.setFromCamera(pointer, camera);
  return raycaster.intersectObjects(clickableMeshes, false).length > 0;
}

function startDelivery() {
  if (state !== "following") return;
  state = "delivering";
  deliveryTime = 0;
  deliveryStart.copy(envelope.position);
  deliveryStartQuaternion.copy(envelope.quaternion);
  canvas.classList.remove("is-hovering");
}

function resetExperience() {
  state = "following";
  deliveryTime = 0;
  flagProgress = 0;
  mailboxBounce = 0;
  flagPivot.rotation.z = -Math.PI / 2;
  envelope.visible = true;
  envelope.scale.setScalar(1);
  envelope.rotation.set(0, 0, 0);
  envelope.position.set(-1.8, 1.2, 4);
}

window.addEventListener("pointermove", updatePointer);
canvas.addEventListener("pointerdown", (event) => {
  updatePointer(event);
  if (pointerHitsMailbox()) startDelivery();
});

function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function easeOutBack(t) {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  renderer.setSize(width, height, false);
  camera.aspect = width / height;

  if (width < 760) {
    camera.position.set(11.5, 7, 27.5);
    camera.lookAt(2.0, -0.35, 0);
  } else {
    camera.position.copy(cameraStart);
    camera.lookAt(0.45, 0.45, 0);
  }
  camera.updateProjectionMatrix();
}

window.addEventListener("resize", resize);
resize();

function animate() {
  const delta = Math.min(clock.getDelta(), 0.04);
  const elapsed = clock.elapsedTime;

  smoothPointer.lerp(pointer, 1 - Math.exp(-delta * 7));

  if (state === "following") {
    raycaster.setFromCamera(smoothPointer, camera);
    camera.getWorldDirection(planeNormal);
    pointerPlane.setFromNormalAndCoplanarPoint(
      planeNormal,
      new THREE.Vector3(0, 0.6, 3.7),
    );
    raycaster.ray.intersectPlane(pointerPlane, followTarget);
    followTarget.x = THREE.MathUtils.clamp(followTarget.x, -4.7, 5.1);
    followTarget.y = THREE.MathUtils.clamp(followTarget.y, -2.5, 3.8);
    envelope.position.lerp(followTarget, 1 - Math.exp(-delta * 8));
    envelope.rotation.z = THREE.MathUtils.lerp(
      envelope.rotation.z,
      -smoothPointer.x * 0.14,
      0.08,
    );
    envelope.rotation.y = THREE.MathUtils.lerp(
      envelope.rotation.y,
      smoothPointer.x * 0.1,
      0.08,
    );

    canvas.classList.toggle("is-hovering", pointerHitsMailbox());
  }

  if (state === "delivering") {
    deliveryTime += delta;
    slot.getWorldPosition(slotWorld);

    const approach = THREE.MathUtils.clamp(deliveryTime / 0.75, 0, 1);
    const approachEase = easeInOutCubic(approach);
    const approachPoint = slotWorld
      .clone()
      .add(new THREE.Vector3(0, 0.03, 0.55));
    envelope.position.lerpVectors(deliveryStart, approachPoint, approachEase);
    envelope.quaternion.slerpQuaternions(
      deliveryStartQuaternion,
      flatEnvelopeQuaternion,
      approachEase,
    );

    if (deliveryTime > 0.75) {
      const insert = THREE.MathUtils.clamp((deliveryTime - 0.75) / 0.5, 0, 1);
      envelope.position.z = THREE.MathUtils.lerp(
        approachPoint.z,
        slotWorld.z - 1.4,
        easeInOutCubic(insert),
      );
      envelope.scale.setScalar(1 - insert * 0.7);
      if (insert >= 1) {
        envelope.visible = false;
        state = "raising-flag";
        mailboxBounce = 1;
      }
    }
  }

  if (state === "raising-flag") {
    flagProgress = Math.min(flagProgress + delta / 0.85, 1);
    const raised = easeOutBack(flagProgress);
    flagPivot.rotation.z = THREE.MathUtils.lerp(-Math.PI / 2, 0, raised);

    if (flagProgress >= 1) {
      state = "delivered";
      window.setTimeout(resetExperience, 3000);
    }
  }

  mailboxBounce *= Math.exp(-delta * 5);
  mailbox.rotation.z = Math.sin(elapsed * 18) * mailboxBounce * 0.045;
  mailbox.position.y =
    0.3 + Math.abs(Math.sin(elapsed * 16)) * mailboxBounce * 0.12;

  if (state === "following") {
    mailbox.rotation.y = -0.08 + Math.sin(elapsed * 0.65) * 0.015;
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}

animate();
